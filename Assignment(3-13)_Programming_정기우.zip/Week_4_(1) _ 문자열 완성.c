// �ǽ� 1 - ���ڿ� �ϼ�
#include <stdio.h>
int stradd(char* end, char* src);
int main(void)
{
	char s1[20] = " 9th Symphony";
	char s2[40] = "Beethoven";

	stradd(s2, s1);

	printf("��ģ ���� : %s \n", s2);

	return 0;
}
int stradd(char* end, char* src)
{
	while (*end)
	{
		end++;
	}
	while (*src)
	{
		*end = *src;
		src++;
		end++;
	}
	*end = '\0';
	return 1;
}