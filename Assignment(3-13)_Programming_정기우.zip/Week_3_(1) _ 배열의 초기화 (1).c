// �ǽ� 1 - �迭�� �ʱ�ȭ (1)
#include <stdio.h>
int main(void)
{
	int grade[5] = { 31, 63, 62, 87, 14 };
	int i;
	for (i = 0; i < 5; i++)
		printf("grade[%d] = %d\n", i, grade[i]);
	return 0;
}