// �ǽ� 2 - ������ ���� 1
#include <stdio.h>
int main(void)
{
	int i = 3000;
	int* p = &i;
	                         // ���â
	printf("&i = %u\n", &i); // &i = 18217924
	printf("i = %d\n", i);   // i = 3000

	printf("*p = %d\n", *p); // *p = 3000
	printf("p = %u\n", p);   // p = 18217924

	return 0;
}