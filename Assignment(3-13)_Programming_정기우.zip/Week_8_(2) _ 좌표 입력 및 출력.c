// �ǽ� 2 - ��ǥ �Է� �� ���
#include<stdio.h>

struct point {
    int xpos;
    int ypos;
};

int main(void) {
    struct point arr[3];
    int i;
    int j;
    for (i = 0; i < 3; i++) {
        printf("���� ��ǥ �Է� : ");
        scanf_s("%d %d", &arr[i].xpos, &arr[i].ypos);
    }
    for (j = 0; j < 3; j++) {
        printf("[%d, %d]. ", arr[j].xpos, arr[j].ypos);
    }

    return 0;
}