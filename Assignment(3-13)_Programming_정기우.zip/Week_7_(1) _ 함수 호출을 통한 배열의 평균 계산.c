// �ǽ� 1 - �Լ� ȣ���� ���� �迭�� ��� ���
#include <stdio.h>

double average(int*);

int main(void) {
	// IF WE ASSUME THAT a[5]'s VARIABLE TYPE
	//                -> DOUBLE (as like lecture)
	// Probably we will check Initialize Error ...
	// So I Use "INT TYPE a[5]"
	int a[5] = { 10,20,30,40,50 };
	double ave=0;
	ave = average(a);
	printf("Average = %f\n", ave);
	return 0;
}

double average(int* num) {
	int i, sum = 0;
	double avg=0;
	for (i = 0; i < 5; i++)
		sum += num[i];
	avg = sum / 5.0;
	return avg;
}