// �ǽ� 3 - �ּҰ� ã��
#include<stdio.h>
#define SIZE 10
int main(void)
{
	int prices[SIZE] = { 0 };
	int i, minimum;
	printf("�ѤѤѤѤѤѤѤѤѤ�\n");
	printf("1 2 3 4 5 6 7 8 9 10\n");
	printf("�ѤѤѤѤѤѤѤѤѤ�\n");

	for (i = 0; i < SIZE; i++)
	{
		prices[i] = (i * 100) % 17;
		printf("%d ", prices[i]);
	}
	printf("\n\n");
	minimum = prices[0];
	for (i = 0; i < SIZE; i++)
	{
		if (prices[i]<minimum)
		{
			minimum = prices[i];
		}
	}
	printf("�ּҰ��� %d�Դϴ�. \n", minimum);

	return 0;
}