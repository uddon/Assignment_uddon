// �ǽ� 2 - �����͸� �̿��� Swap
#include <stdio.h>

void swap(int* ptr1, int* ptr2)
{
	int temp = 0;
	temp = *ptr1;
	*ptr1 = *ptr2;
	*ptr2 = temp;
}

int main (void)
{
	int num1 = 10, num2 = 20;
	printf("Origin  Num 1 : %d, Origin  Num 2 : %d\n", num1, num2);
	swap(&num1, &num2);
	printf("Changed Num 1 : %d, Changed Num 2 : %d\n", num1, num2);
	return 0;
}