// �ǽ� 2 - �����͸� �̿��� �迭 ���� ���
#include<stdio.h>

void reverse(int* Array, int n);

int main(void)
{
	int a[5] = { 10, 20, 30, 40, 50 };
	int i;
	for (i = 0; i < 5; i++)
		printf("%d ", a[i]);
	printf("\n");
	reverse(a, 5);

}
void reverse(int* Array, int n)
{
	int i, temp;
	n = n - 1;
	for (i = 0; i <= n / 2; i++)
	{
		temp = Array[n - i];
		Array[n - i] = Array[i];
		Array[i] = temp;
	}
	for (i = 0; i < 5; i++)
		printf("%d ", Array[i]);
}